package com.spring.udemy.springudemy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringUdemyApplicationTests {

	@Test
	void contextLoads() {
	}

}
